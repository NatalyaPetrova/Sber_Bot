from django.shortcuts import render, redirect
from django.shortcuts import get_object_or_404
from django.utils.dateparse import parse_date
from django.views.decorators.http import require_POST
from .models import SickDay


def index(request):
    if request.method == 'POST':
        Employee.objects.create(
            name=request.POST['name'],
            role=request.POST['role'],
            service_speed=float(request.POST['service_speed']),
            experience=int(request.POST['experience']),
            productivity=int(request.POST['productivity']),
            preferred_day_off_1=request.POST.get('preferred_day_off_1'),
            preferred_day_off_2=request.POST.get('preferred_day_off_2'),
        )
        return redirect('index')

    employees = Employee.objects.all()
    return render(request, 'schedule/index.html', {'employees': employees})


# def mark_sick(request):
#     if request.method == 'POST':
#         employee_id = request.POST['employee_id']
#         start = parse_date(request.POST['sick_start'])
#         end = parse_date(request.POST['sick_end'])
#
#         if employee_id and start and end and start <= end:
#             SickDay.objects.create(
#                 employee_id=employee_id,
#                 start_date=start,
#                 end_date=end
#             )
#     return redirect('generate_schedule')

def delete_employee(request, employee_id):
    employee = get_object_or_404(Employee, id=employee_id)
    employee.delete()
    return redirect('index')


# Параметры смены
MAX_WORK_HOURS = 160
DAYS_IN_MONTH = 30
BASE_MIN_STAFF = 6



@require_POST
def set_shift_config(request):
    request.session['min_staff'] = int(request.POST.get('min_staff', 6))
    return redirect('index')


from .models import Employee
from collections import defaultdict
import random


def generate_schedule(request):
    employees = list(Employee.objects.all())
    if not employees:
        return render(request, 'schedule/schedule.html', {'schedule': {}, 'days': list(range(1, 31))})

    schedule = defaultdict(dict)
    strengths = {e.id: (e.service_speed + e.experience + e.productivity) / 3 for e in employees}
    avg_strength = sum(strengths.values()) / len(strengths)
    hours_worked = {e.id: 0 for e in employees}
    days_off = {e.id: 0 for e in employees}
    days = list(range(1, 31))

    min_staff = request.session.get('min_staff', 6)

    for day in days:
        available = [e for e in employees if hours_worked[e.id] < 160]
        random.shuffle(available)

        required_staff = min_staff + 1 if day <= 18 else min_staff
        selected = []

        # Назначаем кассира или СМО
        cashier = next((e for e in available if e.role == 'кассир' and hours_worked[e.id] + 11 <= 160), None)
        if not cashier:
            cashier = next((e for e in available if e.role == 'СМО' and hours_worked[e.id] + 11 <= 160), None)

        if cashier:
            schedule[cashier.name][day] = "09:45–21:00"
            hours_worked[cashier.id] += 11
            available.remove(cashier)
            selected.append(cashier)

        # Остальные смены
        for e in available:
            if len(selected) >= required_staff:
                break

            shift = random.choice([
                ("10:00–19:00", 9),
                ("10:00–20:00", 10),
                ("10:00–21:00", 11),
                ("11:00–21:00", 10),
                ("12:00–21:00", 9)
            ])

            if hours_worked[e.id] + shift[1] <= 160:
                schedule[e.name][day] = shift[0]
                hours_worked[e.id] += shift[1]
                selected.append(e)

        # Всем остальным — выходной
        for e in employees:
            if e not in selected and day not in schedule[e.name]:
                day_str = f"2025-05-{day:02d}"
                if day_str == str(e.preferred_day_off_1) or day_str == str(e.preferred_day_off_2):
                    schedule[e.name][day] = "Выходной (запрошено)"
                else:
                    schedule[e.name][day] = "Выходной"
                days_off[e.id] += 1

    # Подсчёт статистики
    stats = {
        e.name: {
            'hours': hours_worked[e.id],
            'off_days': days_off[e.id]
        }
        for e in employees
    }

    return render(request, 'schedule/schedule.html', {
        'schedule': dict(schedule),
        'days': days,
        'stats': stats
    })