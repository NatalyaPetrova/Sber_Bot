from django.urls import path
from . import views


urlpatterns = [
    path('', views.index, name='index'),
    path('delete/<int:employee_id>/', views.delete_employee, name='delete_employee'),
    path('generate_schedule/', views.generate_schedule, name='generate_schedule'),
    path('set_shift_config/', views.set_shift_config, name='set_shift_config'),
]