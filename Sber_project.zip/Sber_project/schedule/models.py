from django.db import models

class Employee(models.Model):
    name = models.CharField(max_length=100)
    role = models.CharField(max_length=20)  # кассир, СКМ, СМО
    service_speed = models.FloatField()
    experience = models.IntegerField()
    productivity = models.IntegerField()
    preferred_day_off_1 = models.CharField(max_length=10, blank=True, null=True)
    preferred_day_off_2 = models.CharField(max_length=10, blank=True, null=True)

    def __str__(self):
        return f"{self.name} ({self.role})"

class SickDay(models.Model):
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE)
    start_date = models.DateField()
    end_date = models.DateField()